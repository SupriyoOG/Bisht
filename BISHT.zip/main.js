const games = document.getElementById('games')
const about = document.getElementById('about')
